package main;
//originator class
/**
 * This class is used to initiate the Memento.
 * @author Hetvi
 *
 */

public class BeginMemento {
  private String state;
 
  /**
 * This method is used to set the state of the incoming object.
 * @param state object 
 */
  public void setState(String state) {
    this.state = state;
  }
  
  /**
 * It is the method to retrieve the state of object.
 * @return state object
 */
  public String getState() {
    return state;
  }
 
  /**
  * It returns the state of new memento object.
  * @return state object
  */
  public CreateMemento saveStateToMemento() {
    return new CreateMemento(state);
  }
  
  /**
 * This method saves the memento object. 
  */
 
  public void getStateFromMemento(CreateMemento memento) {
    state = memento.getState();
  }
}
