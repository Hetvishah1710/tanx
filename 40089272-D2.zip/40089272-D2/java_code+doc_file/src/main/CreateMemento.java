package main;
//memento class

/**
 * this class is used to create the memento object.
 * @author Hetvi
 *
 */
public class CreateMemento {
  private String state;
  
  /**
  * this constructor is used to initialize memento object.
  * @param state object
  */
  public CreateMemento(String state) {
    this.state = state;
  }

  /**
   * returns the state of that object.
   * @return state object
   */
  public String getState() {
    return state;
  }

}
