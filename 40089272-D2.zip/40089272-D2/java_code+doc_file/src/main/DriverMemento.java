package main;

import java.util.ArrayList;
import java.util.List;

/**
 * This class drives the handles the methods and objects.
 * @author jai shree krishna
 *
 */
public class DriverMemento {
  public List<CreateMemento> mementoList = new ArrayList<CreateMemento>();
  
  /**
   * This method creates the memento and it to the memento list.
   * @param state object
   */
  public void add(CreateMemento state) {
    mementoList.add(state);
  }

  /**
   * This method gets the tan value at particular index in memento list.
   * @param index value
   * @return state object
   */
  public CreateMemento get(int index) {
    return mementoList.get(index);
  }
}

