package main;

import java.text.DecimalFormat;
import java.util.Scanner;
import javax.swing.plaf.synth.SynthSeparatorUI;
//import javafx.event.Event;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Alert.AlertType;


/**
 *This is the main tangent class which implements the functionalities such as calculation of sin 
 *value,
 * cosine value and tan value
 * and it also validates the input values depending on domain. 
 * @author Hetvi
 *
 */
public class Tan {
  static int i;
  
  public static BeginMemento beginMemento = new BeginMemento();
  public static DriverMemento driver = new DriverMemento();
  public static double tanvalue1;
  /**
  * This is Default constructor.
*/

  public Tan() {

  }
    
  /**
  * This is the driver class.
  * @param args parameter
*/
  public static void main(String[] args) {
    // TODO Auto-generated method stub
    Scanner sc = new Scanner(System.in);
   
    System.out.println("*****************************************");
    System.out.println("*      This is tan function calclator   *");
    System.out.println("*****************************************");
    
    System.out.println("\n**************************************");
    System.out.println("* Press 1 to compute tan value       *");
    System.out.println("* Press 2 to retrive previous result *");
    System.out.println("* Press 3 to store previous value    *");
    System.out.println("* Press 4 exit                       *");
    System.out.println("**************************************");
    System.out.println("\nEnter your choice :");
    int op = sc.nextInt();
    Tan tan1 = new Tan();
    while (true) {
      if (op == 1) {
        System.out.println("\nEnter the value of x in degree :");
        //float x = sc.nextFloat();
        double x = Double.parseDouble(sc.next());
        
        while (!(tan1.validateValue(x))) {
          System.out.println("Enter the value of x in degree : ");
          x = Double.parseDouble(sc.next());
        }
       
        double tan;
        tanvalue1 = tan1.tanf(x);
        System.out.println("* value of tan :" + tanvalue1);
        System.out.println("*****************************");
      }
      if (op == 2) {
        tan1.retrieveResult();
      }
      if (op == 3) {
        tan1.storeResult();
      }
      if (op == 4) {
        System.exit(0);
      }
      System.out.println("\n**************************************");
      System.out.println("* Press 1 to compute tan value       *");
      System.out.println("* Press 2 to retrive previous result *");
      System.out.println("* Press 3 to store previous value    *");
      System.out.println("* Press 4 exit                       *");
      System.out.println("**************************************");
      System.out.println("\nEnter your choice :");
      op = sc.nextInt();
    }
      
  }
  /**
 * It stores the result of tan function for the future use.
 */
  
  public void storeResult() {
    System.out.println("Value of result is stored !!");
    beginMemento.setState("" + tanvalue1);
    driver.add(beginMemento.saveStateToMemento());
  }
  /**
   * It retrieves the result form the previous calculation.
   */
  
  public void retrieveResult() {
    System.out.println("Previous result is retrived !!");
    for (int i = 0;i < driver.mementoList.size();i++) {
      beginMemento.getStateFromMemento(driver.get(i));
      System.out.println("History : " + beginMemento.getState());
    }
  }
  /**
  * This is validation method which tests input value is within the function's domain or not 
  * using exception handling. 
* @param x input value
* @return true if it is properly defined otherwise returns false
*/
  
  public boolean validateValue(double x) {

    try { 
      for (int i = 1;i < 9999;i = i + 2) {
        double temp = 90 * i;
        if (temp == x || temp == -x) {
          System.out.println("Value of x should be within its domain!!");
          return false;
        }
      }
      return true;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }

  /**
* This is the tangent method which calculates tan value of input using sin and cosine value.
* @param r input value  
* @return result of tan value of r
*/
  public double tanf(double r) {
    double sinvalue1 = sinf(r);
    //value of sin
    System.out.println("*****************************");
    System.out.println("*           Result          *");
    System.out.println("*****************************");
    System.out.println("* value of sin :" + sinvalue1);
    double cosvalue1 = cosf(r);
    //value of cos
    System.out.println("* value of cos :" + cosvalue1);
    double output = sinvalue1 / cosvalue1;
    DecimalFormat df = new DecimalFormat(".#####");
    output = Double.parseDouble(df.format(output));
    return output;
  }

  /**
* This method calculates cosine value. 
* @param r input 
* @return result of cosine value using maclaurin's series
*/
  public  double cosf(double r) {
    double pi = Math.PI;
    //converting it to radian
    r = (r / 180) * pi;
    boolean flag = true;
    double output = 0;
    int i = 1;
    for (i = 0;i < 7;i++) {
      int n = 2 * i;
      if (i % 2 == 0) {
        output += (power(r,n)) / fact(n);
      } else {
        output -= (power(r,n)) / fact(n);
      }

    }
    DecimalFormat df = new DecimalFormat(".#####");
    output = Double.parseDouble(df.format(output));
    return output;
  }

  /**
* This method calculates sine value.
* @param r input 
* @return result of sine value using maclaurin's series
*/
  public double sinf(double r) {
    double pi = Math.PI;
    //converting it to radian
    r = (r / 180) * pi;
    boolean flag = true;
    double output = 0;
    int i = 1;
    for (i = 0;i < 7;i++) {
      int n = 2 * i + 1;
      if (i % 2 == 0) {
        output += (power(r,n)) / fact(n);
      } else {
        output -= (power(r,n)) / fact(n);
      }

    }
    DecimalFormat df = new DecimalFormat(".#####");
    output = Double.parseDouble(df.format(output));
    return output;
  }



  /**
* This method calculates power value. 
* @param r base value 
* @param i exponent value
* @return result of r raised to the power i.
*/
  public double power(double r, int i) {
    double output = 1;
    for (int j = i;j != 0; j--) {
      output *= r;
    }
    // System.out.println("Answer = " + result);

    DecimalFormat df = new DecimalFormat(".#####");
    output = Double.parseDouble(df.format(output));
    return output;
  }

  /**
 * This is factorial implementation using iteration method.
 * @param r input value
 * @return result of factorial
 */
  public double fact(double r) {

    int fact = 1;  
    if (r == 0) {
      return fact;
    }
    double number = r;//It is the number to calculate factorial    
    for (int k = 1;k <= number;k++) {
      fact = fact * k;
    }
    //System.out.println("Factorial of "+number+" is: "+fact);
    return fact;
  }
}

