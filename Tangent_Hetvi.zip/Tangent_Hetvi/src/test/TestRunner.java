package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


/**
 * This is a runner class for tanTest file.
 * @author Hetvi
 *
 */
@RunWith(Suite.class)
@SuiteClasses({tanTest.class})
public class TestRunner{
	
}


