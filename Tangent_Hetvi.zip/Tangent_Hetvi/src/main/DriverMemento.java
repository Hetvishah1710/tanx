package main;

import java.util.ArrayList;
import java.util.List;

public class DriverMemento {
  private List<BeginMemento> mementoList = new ArrayList<BeginMemento>();
  
  public void add(BeginMemento state) {
    mementoList.add(state);
  }

  public BeginMemento get(int index) {
    return mementoList.get(index);
  }
}

