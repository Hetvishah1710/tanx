package main;
//memento class

public class CreateMemento {
  private String state;
  
  public CreateMemento(String state) {
    this.state = state;
  }

  public String getState() {
    return state;
  }

}
