package main;
//originator class

public class BeginMemento {
  private String state;

  public void setState(String state) {
    this.state = state;
  }

  public String getState() {
    return state;
  }
 
  public CreateMemento saveStateToMemento() {
    return new CreateMemento(state);
  }

  public void getStateFromMemento(CreateMemento memento) {
    state = memento.getState();
  }
}
